# Firelink
Firefox extension to create short links using Shlink
This extension helps you create sharable shortlinks instantly. 

## Usage
User your own shlink server and configure your API Key in the options.
Due to the possible abuse of the API Key / my domain there is no public API Key for this project. 
