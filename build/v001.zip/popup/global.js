document.getElementById("closeButton").addEventListener("click", () => {
    window.location.href = "index.html";
});

document.getElementById("optionsButton").addEventListener("click", () => {
    window.location.href = "options.html";
});
